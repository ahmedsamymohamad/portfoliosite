// Vendor Imports
import 'bootstrap';

// Components
import './components/dark-mode';
import './components/locomotive-scroll';
import './components/swiper';
import './components/typed';

// theme misc js
import './misc';